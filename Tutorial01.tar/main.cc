#include "defs.h"
#include <iostream>
#include <cstdlib>

int main(){
	srand((unsigned)time(NULL));
	int arr[MAX_ARR_SIZE];
	initArray(arr);
	printArray(arr);

	for(int i = 0; i < MAX_ARR_SIZE; i++){
		doubleNum(arr[i]);
	}
	
	printArray(arr);
	return 0;
}

void printArray(int* array){
	std::cout << "[";
	for(int i = 0; i < MAX_ARR_SIZE; i++){
		std::cout << array[i] << ", ";
	}
	std::cout << "]\n";
}
