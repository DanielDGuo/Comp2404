#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR_SIZE  16

void initArray(int*);
void printArray(int*);
bool checkNum(int);
void doubleNum(int&);
int  random(int);

#endif

